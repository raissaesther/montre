<div class="qode-register-notice">
	<h5 class="qode-register-notice-title"><?php echo esc_html($message); ?></h5>
	<a href="#" class="qode-login-action-btn" data-el="#qode-login-content" data-title="<?php esc_html_e('LOGIN', 'qode_membership'); ?>"><?php esc_html_e('LOGIN', 'qode_membership'); ?></a>
</div>